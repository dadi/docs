---
title: Debug
layout: default.html
---

### Debug Mode

```
{>"debug/partials/debug-panel" /}
```
