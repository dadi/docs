---
title: Configuration
layout: default.html
---

## Configuration

### Overview

DADI Web starts with a default configuration.

This is the basic configuration you need to get your web server running:

*config.development.json*

```
{
  "app": {
    "name": "Your Project"
  },
  "server": {
    "host": "localhost",
    "port": 3000
  },
  "api": {
    "enabled": false
  }
}
```

